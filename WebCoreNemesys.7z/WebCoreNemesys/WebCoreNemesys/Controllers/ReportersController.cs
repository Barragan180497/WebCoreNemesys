﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebCoreNemesys.Models;

namespace WebCoreNemesys.Controllers
{
    public class ReportersController : Controller
    {
        private readonly MvcNemesysContext _context;

        public ReportersController(MvcNemesysContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> ReporterRank()
        {
            return View(await _context.Reporters.ToListAsync());
        }

        private bool ReportExists(int id)
        {
            return _context.Reporters.Any(e => e.ReportID == id);
        }
    }
}