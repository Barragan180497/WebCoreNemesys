﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace WebCoreNemesys.Models
{
    public class Report
    {
        [Key]
        public int ReportID { get; set; }

        [Required(ErrorMessage = "You must enter {0}"), Display(Name = "Report Date")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy / MM / dd}", ApplyFormatInEditMode = true)]
        public DateTime ReportDate { get; set; }

        [Required(ErrorMessage = "You must enter {0}")]
        public string Location { get; set; }

        [Required(ErrorMessage = "You must enter {0}"), Display(Name = "Detection Date")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy / MM / dd}", ApplyFormatInEditMode = true)]
        public DateTime DetectionDate { get; set; }

        [Required(ErrorMessage = "You must enter {0}"), Display(Name = "Detection Hour")]
        [DataType(DataType.Time)]
        [DisplayFormat(DataFormatString = "{0:hh: mm}", ApplyFormatInEditMode = true)]
        public DateTime DetectionHour { get; set; }

        [Required(ErrorMessage = "You must enter {0}"), Display(Name = "Danger Type")]
        public string DangerType { get; set; }

        [Required(ErrorMessage = "You must enter {0}")]
        [DataType(DataType.MultilineText)]
        public string Description { get; set; }

        public string State { get; set; }

        [Display(Name = "Image")]
        public string FileType { get; set; }

        [Required(ErrorMessage = "You must enter {0}"), DataType(DataType.EmailAddress)]
        public string EMail { get; set; }

        [Display(Name = "Phone Number")]
        public float PhoneNumber { get; set; }
    }
}
