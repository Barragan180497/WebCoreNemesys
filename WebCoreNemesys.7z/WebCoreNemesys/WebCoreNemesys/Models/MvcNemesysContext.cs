﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace WebCoreNemesys.Models
{
    public class MvcNemesysContext : DbContext
    {
        public MvcNemesysContext(DbContextOptions<MvcNemesysContext> options)
            : base(options)
        {
        }

        public DbSet<Report> Reporters { get; set; }
    }
}
