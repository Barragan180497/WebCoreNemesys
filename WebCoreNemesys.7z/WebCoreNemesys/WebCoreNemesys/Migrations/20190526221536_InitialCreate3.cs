﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace WebCoreNemesys.Migrations
{
    public partial class InitialCreate3 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_Reports",
                table: "Reports");

            migrationBuilder.RenameTable(
                name: "Reports",
                newName: "Reporters");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Reporters",
                table: "Reporters",
                column: "ReportID");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropPrimaryKey(
                name: "PK_Reporters",
                table: "Reporters");

            migrationBuilder.RenameTable(
                name: "Reporters",
                newName: "Reports");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Reports",
                table: "Reports",
                column: "ReportID");
        }
    }
}
